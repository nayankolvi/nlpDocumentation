patternRegEx = {
    "state" : r"The (?s)(.*) shall have (?s)(.*) state.",
    "initial" : r"The (?s)(.*) shall transit to (?s)(.*) from initial state.",
    "entry" : r"As soon as the (?s)(.*) enters the state (?s)(.*), the (?s)(.*) shall (?s)(.*).",
    "do" : r"As long as the (?s)(.*) is in the state (?s)(.*), the (?s)(.*) shall have the ability to (?s)(.*).",
    "exit" : r"As soon as the (?s)(.*) exits the state (?s)(.*), the (?s)(.*) shall (?s)(.*).",
    "transitions" : r"As long as the (?s)(.*) exits the state (?s)(.*), the vehicle shall have the ability to go to the state (?s)(.*).",
    "CondTransitions" : r"As soon as the (?s)(.*) exits the state (?s)(.*) and (?s)(.*), the (?s)(.*) shall (?s)(.*) and go to the state (?s)(.*).",
    "CondTransitionsWithEvents" : r"As soon as the(?s)(.*) receives the signal (?s)(.*) and the (?s)(.*) is in the (?s)(.*) state and (?s)(.*), the (?s)(.*) shall (?s)(.*) and go to the state (?s)(.*)."
}

regExMatchGroups = {
    "state" : ["systemName", "m_fromState"],
    "initial" : ["systemName", "m_toState"],
    "entry" : ["systemName", "m_fromState", "systemName", "m_entryAction"],
    "do" : ["systemName", "m_fromState", "systemName", "m_doAction"],
    "exit" : ["systemName", "m_fromState", "systemName", "m_exitAction"],
    "transitions" : ["systemName, m_fromState, m_toState"],
    "CondTransitions" : ["systemName", "m_fromState", "m_guard", "systemName", "m_action", "m_toState"],
    "CondTransitionsWithEvents" : ["systemName", "m_event", "systemName", "m_fromState", "m_guard", "systemName", "m_action", "m_toState"]
}

textData = [
    "The Traffic lights shall have red state.",
    "The Traffic lights shall have yellow state.",
    "The Traffic lights shall have green state.",
    "The Traffic lights shall transit to red from initial state.",
    "As soon as the Traffic lights enters the state red, the Traffic lights shall turn on red led.",
    "As soon as the Traffic lights enters the state yellow, the Traffic lights shall turn on yellow led.",
    "As soon as the Traffic lights enters the state green, the Traffic lights shall turn on green led.",
    "As long as the Traffic lights is in the state red, the Traffic lights shall have the ability to check if timer reached 1 min.",
    "As long as the Traffic lights is in the state yellow, the Traffic lights shall have the ability to check if timer reached 10 sec.",
    "As long as the Traffic lights is in the state green, the Traffic lights shall have the ability to check if timer reached 30 sec."
    "As soon as the Traffic lights receives the signal timeout and the Traffic lights is in the red state and 1 min expired, the Traffic lights shall turn off red light and go to the state yellow.",
    "As soon as the Traffic lights receives the signal timeout and the Traffic lights is in the yellow state and 10 sec expired and previous state is green, the Traffic lights shall turn off red light and go to the state red.",
    "As soon as the Traffic lights receives the signal timeout and the Traffic lights is in the yellow state and 10 sec expired and previous state is red, the Traffic lights shall turn off red light and go to the state green.",
    "As soon as the Traffic lights receives the signal timeout and the Traffic lights is in the green state and 30 sec expired, the Traffic lights shall turn off red light and go to the state red."
]