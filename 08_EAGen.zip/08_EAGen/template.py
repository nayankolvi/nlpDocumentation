# templates = [systemName
#     "<group name="state">The {{ systemName }} shall have {{ stateName }} state.</group>",
#     "<group name="initial">The {{ systemName }} shall transit to {{ tostateName }} from {{ stateName }} state.</group>"
#     "<group name="entry">As soon as the {{ systemName }} enters the state {{ stateName }}, the {{ systemName }} shall {{ entryAction }}.</group>",
#     "<group name="do">As long as the {{ systemName }} is in the state {{ stateName }}, the {{ systemName }} shall have the ability to {{ entryAction }}.</group>",
#     "<group name="exit">As soon as the {{ systemName }} exits the state {{ stateName }}, the {{ systemName }} shall {{ exitAction }}.</group>",
#     "<group name="transitions">As long as the {{ systemName }} exits the state {{ stateName }}, the vehicle shall have the ability to go to the state {{ tostateName }}.</group>",
#     "<group name="CondTransitions">As soon as the {{ systemName }} exits the state {{ stateName }} and {{ guard }}, the {{ systemName }} shall {{ transitionAction }} and go to the state {{ tostateName }}.</group>",
#     "<group name="CondTransitionsWithEvents"As soon as the {{ systemName }} receives the signal <trigger> AND the <system> is in the  {{ stateName }} state and {{ guard }}, the {{ systemName }} shall {{ transitionAction }} and go to the state {{ tostateName }}.</group>"
# ]

# templateSM = """
# <group name="state" containsall="systemName, stateName">The {{ systemName }} shall have {{ stateName }} state.</group>
# <group name="initial">The {{ systemName }} shall transit to {{ tostateName }} from {{ stateName }} state.</group>
# """

# <group name="initial">The {{ systemName }} shall transit to {{ tostateName }} from {{ stateName }} state.</group>
# <group name="entry">As soon as the {{ systemName }} enters the state {{ stateName }}, the {{ systemName }} shall {{ entryAction }}.</group>
# <group name="do">As long as the {{ systemName }} is in the state {{ stateName }}, the {{ systemName }} shall have the ability to {{ entryAction }}.</group>
# <group name="exit">As soon as the {{ systemName }} exits the state {{ stateName }}, the {{ systemName }} shall {{ exitAction }}.</group>
# <group name="transitions">As long as the {{ systemName }} exits the state {{ stateName }}, the vehicle shall have the ability to go to the state {{ tostateName }}.</group>
# <group name="CondTransitions">As soon as the {{ systemName }} exits the state {{ stateName }} and {{ guard }}, the {{ systemName }} shall {{ transitionAction }} and go to the state {{ tostateName }}.</group>
# <group name="CondTransitionsWithEvents"As soon as the {{ systemName }} receives the signal <trigger> AND the <system> is in the  {{ stateName }} state and {{ guard }}, the {{ systemName }} shall {{ transitionAction }} and go to the state {{ tostateName }}.</group>

#groups = ["state", "initial", "entry", "do", "exit", "transitions", "CondTransitions", "CondTransitionsWithEvents"]

# groupSM = {
#     "state" : """ <group name="state" containsall="systemName, stateName">The {{ systemName }} shall have {{ stateName }} state.</group> """,

#     "initial" : """ <group name="initial" containsall="systemName, tostateName, stateName">The {{ systemName }} shall transit to {{ tostateName }} from {{ stateName }} state.</group> """,

#     "entry" : """ <group name="entry" containsall="systemName, stateName, systemName_duplicate, entryAction">As soon as the {{ systemName }} enters the state {{ stateName }}, the {{ systemName_duplicate }} shall {{ entryAction }}.</group> """,

#     "do" : """ <group name="do" containsall="systemName, stateName, systemName_duplicate, doAction">As long as the {{ systemName }} is in the state {{ stateName }}, the {{ systemName_duplicate }} shall have the ability to {{ doAction }}.</group> """,

#     "exit" : """ <group name="exit" containsall="systemName, stateName, systemName_duplicate, exitAction">As soon as the {{ systemName }} exits the state {{ stateName }}, the {{ systemName_duplicate }} shall {{ exitAction }}.</group> """,

#     "transitions" : """ <group name="transitions" containsall="systemName, stateName, tostateName">As long as the {{ systemName }} exits the state {{ stateName }}, the vehicle shall have the ability to go to the state {{ tostateName }}.</group> """,

#     "CondTransitions" : """ <group name="CondTransitions" containsall="systemName, stateName, guard, systemName_duplicate, transitionAction, tostateName">As soon as the {{ systemName }} exits the state {{ stateName }} and {{ guard }}, the {{ systemName_duplicate }} shall {{ transitionAction }} and go to the state {{ tostateName }}.</group> """,

#     "CondTransitionsWithEvents" : """<group name="CondTransitionsWithEvents" containsall="systemName, trigger, systemName_duplicate, stateName, guard, systemName_duplicate2, transitionAction, tostateName"> As soon as the {{ systemName }} receives the signal {{ trigger }} and the {{ systemName_duplicate }} is in the {{ stateName }} state and {{ guard }}, the {{ systemName_duplicate2 }} shall {{ transitionAction }} and go to the state {{ tostateName }}.</group>"""
# }
    # 



    # "entry" : """ <group name="entry" containsall="systemName, stateName, systemName_duplicate, entryAction">As soon as the {{ systemName }} enters the state {{ stateName }}, the {{ systemName_duplicate }} shall {{ entryAction }}.</group> """,
    # "do" : """ <group name="do" containsall="systemName, stateName, systemName_duplicate, doAction">As long as the {{ systemName }} is in the state {{ stateName }}, the {{ systemName_duplicate }} shall have the ability to {{ doAction }}.</group> """,
    # "exit" : """ <group name="exit" containsall="systemName, stateName, systemName_duplicate, exitAction">As soon as the {{ systemName }} exits the state {{ stateName }}, the {{ systemName_duplicate }} shall {{ exitAction }}.</group> """,
    # "transitions" : """ <group name="transitions" containsall="systemName, stateName, tostateName">As long as the {{ systemName }} exits the state {{ stateName }}, the vehicle shall have the ability to go to the state {{ tostateName }}.</group> """,
    # "CondTransitions" : """ <group name="CondTransitions" containsall="systemName, stateName, guard, systemName_duplicate, transitionAction, tostateName">As soon as the {{ systemName }} exits the state {{ stateName }} and {{ guard }}, the {{ systemName_duplicate }} shall {{ transitionAction }} and go to the state {{ tostateName }}.</group> """,
    # "CondTransitionsWithEvents" : """ <group name="CondTransitionsWithEvents" containsall="systemName, trigger, system, stateName, guard, systemName_duplicate, transitionAction, tostateName" >As soon as the {{ systemName }} receives the signal <trigger> AND the <system> is in the  {{ stateName }} state and {{ guard }}, the {{ systemName_duplicate }} shall {{ transitionAction }} and go to the state {{ tostateName }}.</group> """

textData = [
    "The Traffic lights shall have red state.",
    "The Traffic lights shall have yellow state.",
    "The Traffic lights shall have green state.",
    "The Traffic lights shall transit to red from initial state.",
    "As soon as the Traffic lights enters the state red, the Traffic lights shall turn on red led.",
    "As soon as the Traffic lights enters the state yellow, the Traffic lights shall turn on yellow led.",
    "As soon as the Traffic lights enters the state green, the Traffic lights shall turn on green led.",
    "As long as the Traffic lights is in the state red, the Traffic lights shall have the ability to check if timer reached 1 min.",
    "As long as the Traffic lights is in the state yellow, the Traffic lights shall have the ability to check if timer reached 10 sec.",
    "As long as the Traffic lights is in the state green, the Traffic lights shall have the ability to check if timer reached 30 sec.",
    "As soon as the Traffic lights receives the signal timeout_RtoY and the Traffic lights is in the red state and 1 min expired, the Traffic lights shall turn off red light and go to the state yellow.",
    "As soon as the Traffic lights receives the signal timeout_YtoR and the Traffic lights is in the yellow state and 10 sec expired and previous state is green, the Traffic lights shall turn off yellow light and go to the state red.",
    "As soon as the Traffic lights receives the signal timeout_YtoG and the Traffic lights is in the yellow state and 10 sec expired and previous state is red, the Traffic lights shall turn off yellow light and go to the state green.",
    "As soon as the Traffic lights receives the signal timeout GtoY and the Traffic lights is in the green state and 30 sec expired, the Traffic lights shall turn off green light and go to the state yellow."
]


patternRegEx = {
    "state" : r"The (?s)(.*) shall have (?s)(.*) state.",
    "initial" : r"The (?s)(.*) shall transit to (?s)(.*) from initial state.",
    "entry" : r"As soon as the (?s)(.*) enters the state (?s)(.*), the (?s)(.*) shall (?s)(.*).",
    "do" : r"As long as the (?s)(.*) is in the state (?s)(.*), the (?s)(.*) shall have the ability to (?s)(.*).",
    "exit" : r"As soon as the (?s)(.*) exits the state (?s)(.*), the (?s)(.*) shall (?s)(.*).",
    "transitions" : r"As long as the (?s)(.*) exits the state (?s)(.*), the vehicle shall have the ability to go to the state (?s)(.*).",
    "CondTransitions" : r"As soon as the (?s)(.*) exits the state (?s)(.*) and (?s)(.*), the (?s)(.*) shall (?s)(.*) and go to the state (?s)(.*).",
    "CondTransitionsWithEvents" : r"As soon as the(?s)(.*) receives the signal (?s)(.*) and the (?s)(.*) is in the (?s)(.*) state and (?s)(.*), the (?s)(.*) shall (?s)(.*) and go to the state (?s)(.*)."
}

regExMatchGroups = {
    "state" : ["systemName", "m_fromState"],
    "initial" : ["systemName", "m_toState"],
    "entry" : ["systemName", "m_fromState", "systemName", "m_entryAction"],
    "do" : ["systemName", "m_fromState", "systemName", "m_doAction"],
    "exit" : ["systemName", "m_fromState", "systemName", "m_exitAction"],
    "transitions" : ["systemName, m_fromState, m_toState"],
    "CondTransitions" : ["systemName", "m_fromState", "m_guard", "systemName", "m_action", "m_toState"],
    "CondTransitionsWithEvents" : ["systemName", "m_event", "systemName", "m_fromState", "m_guard", "systemName", "m_action", "m_toState"]
}
"systemName, trigger, system, stateName, guard, systemName_duplicate, transitionAction, tostateName"